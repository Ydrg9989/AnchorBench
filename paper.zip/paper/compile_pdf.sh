#!/usr/bin/env bash
# Compile colm2026_conference.tex to PDF using Tectonic.
# Usage: bash compile_pdf.sh
set -e
cd "$(dirname "$0")"

if ! command -v tectonic &>/dev/null; then
  echo "Error: tectonic not found. Install with: cargo install tectonic"
  echo "  or: conda install -c conda-forge tectonic"
  exit 1
fi

# Reruns: 2 extra passes for cross-refs and bibliography
tectonic --reruns 2 -o . colm2026_conference.tex

echo "Done: colm2026_conference.pdf"
