#!/usr/bin/env python3
"""Generate revised figures for the COLM paper.

Figure 3 (new): Offset dose-response — UAI by anchor distance, grouped by suite.
"""

import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR = ROOT / "outputs" / "revision_analyses"
FIG_DIR = ROOT / "COLM" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

SUITE_COLORS = {
    "external": "#2166ac",
    "history": "#b2182b",
    "icl": "#999999",
    "rag": "#1b7837",
    "tool": "#e08214",
}
SUITE_LABELS = {
    "external": "External",
    "history": "History",
    "icl": "ICL",
    "rag": "RAG",
    "tool": "Tool",
}

API_MODELS = {"GPT-5.4-mini", "Claude-H4.5", "Gemini-2.5-Flash", "Grok-3-mini"}


def fig_dose_response():
    """Figure 3: UAI_plaus by anchor offset, grouped by suite."""
    with open(DATA_DIR / "a3_offset_dose_response.json") as f:
        data = json.load(f)

    fig, axes = plt.subplots(1, 2, figsize=(5.5, 3.2), sharey=True,
                             gridspec_kw={"width_ratios": [3, 2], "wspace": 0.08})

    offsets = [15, 25, 40]
    x = np.arange(len(offsets))
    width = 0.15

    # Left panel: open-weight model means by suite
    ax = axes[0]
    for i, suite in enumerate(["external", "rag", "tool", "icl"]):
        means = []
        cis = []
        for off in offsets:
            vals = [r["uai_plaus"] for r in data
                    if r["suite"] == suite and r["offset"] == off
                    and r["model"] not in API_MODELS
                    and r.get("uai_plaus") is not None]
            if vals:
                m = np.mean(vals)
                se = np.std(vals) / np.sqrt(len(vals)) if len(vals) > 1 else 0
                means.append(m)
                cis.append(1.96 * se)
            else:
                means.append(0)
                cis.append(0)

        positions = x + (i - 1.5) * width
        ax.bar(positions, means, width * 0.9, yerr=cis,
               color=SUITE_COLORS[suite], alpha=0.85,
               label=SUITE_LABELS[suite], capsize=2, error_kw={"linewidth": 0.8})

    ax.set_xticks(x)
    ax.set_xticklabels([f"$\\delta$={o}" for o in offsets], fontsize=9)
    ax.set_ylabel(r"UAI$_{\mathrm{pls}}$", fontsize=10)
    ax.set_title("Open-weight models", fontsize=9.5, pad=6)
    ax.axhline(0, color="#cccccc", linewidth=0.6, linestyle="-")
    ax.set_ylim(-0.05, 0.40)
    ax.tick_params(labelsize=8.5)
    ax.legend(fontsize=7, ncol=2, loc="upper right",
              framealpha=0.9, handlelength=1.2)

    # Right panel: API model means by suite
    ax = axes[1]
    for i, suite in enumerate(["external", "rag", "tool", "icl"]):
        means = []
        cis = []
        for off in offsets:
            vals = [r["uai_plaus"] for r in data
                    if r["suite"] == suite and r["offset"] == off
                    and r["model"] in API_MODELS
                    and r.get("uai_plaus") is not None]
            if vals:
                m = np.mean(vals)
                se = np.std(vals) / np.sqrt(len(vals)) if len(vals) > 1 else 0
                means.append(m)
                cis.append(1.96 * se)
            else:
                means.append(0)
                cis.append(0)

        positions = x + (i - 1.5) * width
        ax.bar(positions, means, width * 0.9, yerr=cis,
               color=SUITE_COLORS[suite], alpha=0.85,
               capsize=2, error_kw={"linewidth": 0.8})

    ax.set_xticks(x)
    ax.set_xticklabels([f"$\\delta$={o}" for o in offsets], fontsize=9)
    ax.set_title("API models", fontsize=9.5, pad=6)
    ax.axhline(0, color="#cccccc", linewidth=0.6, linestyle="-")
    ax.tick_params(labelsize=8.5)

    fig.suptitle("Plausible-anchor influence by offset distance",
                 fontsize=10.5, y=1.02)
    plt.tight_layout()

    out = FIG_DIR / "fig3_dose_response.pdf"
    fig.savefig(out, bbox_inches="tight", dpi=300)
    fig.savefig(out.with_suffix(".png"), bbox_inches="tight", dpi=300)
    plt.close(fig)
    print(f"Saved: {out}")


if __name__ == "__main__":
    fig_dose_response()
    print("Done.")
