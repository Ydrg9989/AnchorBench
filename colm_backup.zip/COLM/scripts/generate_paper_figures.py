#!/usr/bin/env python3
"""Generate publication-quality figures for the AnchorBench paper."""

import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent.parent
OW_JSON = ROOT / "results" / "full_benchmark" / "unified_all_suites.json"
API_JSON = ROOT / "results" / "api_benchmark" / "unified_all_suites.json"
FIG_DIR = ROOT / "COLM" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# ── Model display names ───────────────────────────────────────
MODEL_SHORT = {
    "Qwen_Qwen2.5-1.5B-Instruct": "Qwen-1.5B",
    "Qwen_Qwen2.5-3B-Instruct": "Qwen-3B",
    "Qwen_Qwen2.5-7B-Instruct": "Qwen-7B",
    "meta-llama_Llama-3.2-1B-Instruct": "Llama-1B",
    "meta-llama_Llama-3.2-3B-Instruct": "Llama-3B",
    "meta-llama_Llama-3.1-8B-Instruct": "Llama-8B",
    "google_gemma-3-1b-it": "Gemma-1B",
    "google_gemma-3-4b-it": "Gemma-4B",
    "allenai_OLMo-2-1124-13B-Instruct": "OLMo-13B",
    "allenai_OLMo-2-0325-32B-Instruct": "OLMo-32B",
    "openai_gpt-5.4-mini": "GPT-5.4-mini",
    "anthropic_claude-haiku-4.5": "Claude-H4.5",
    "google_gemini-2.5-flash": "Gemini-2.5-Flash",
    "x-ai_grok-3-mini-beta": "Grok-3-mini",
}

SUITE_ORDER = ["External", "History", "Icl", "Rag", "Tool"]
SUITE_DISPLAY = {"External": "External", "History": "History",
                 "Icl": "ICL", "Rag": "RAG", "Tool": "Tool"}

OW_MODEL_ORDER = [
    "Gemma-1B", "Llama-1B", "Qwen-1.5B",
    "Qwen-3B", "Llama-3B", "Gemma-4B",
    "Qwen-7B", "Llama-8B",
    "OLMo-13B", "OLMo-32B",
]
API_MODEL_ORDER = [
    "GPT-5.4-mini", "Claude-H4.5", "Gemini-2.5-Flash", "Grok-3-mini",
]

SUITE_COLORS = {
    "External": "#2166ac",
    "History": "#b2182b",
    "ICL": "#999999",
    "RAG": "#1b7837",
    "Tool": "#e08214",
}


def load_data():
    with open(OW_JSON) as f:
        ow = json.load(f)
    with open(API_JSON) as f:
        api = json.load(f)
    records = []
    for r in ow + api:
        slug = r.get("model_slug", "")
        suite = r.get("suite", "")
        short = MODEL_SHORT.get(slug, slug)
        records.append({
            "model": short,
            "suite": SUITE_DISPLAY.get(suite, suite),
            "acc10": r.get("acc10_control"),
            "disc_delta": r.get("disc_delta"),
            "uai_irr": r.get("uai_irr"),
            "uai_pls": r.get("uai_plaus"),
            "is_api": slug in {
                "openai_gpt-5.4-mini", "anthropic_claude-haiku-4.5",
                "google_gemini-2.5-flash", "x-ai_grok-3-mini-beta",
            },
        })
    return records


def fig_disc_heatmap(records):
    """Figure 2: Disc_Δ heatmap (models × suites)."""
    model_order = OW_MODEL_ORDER + API_MODEL_ORDER
    suite_labels = [SUITE_DISPLAY[s] for s in SUITE_ORDER]

    lookup = {}
    for r in records:
        lookup[(r["model"], r["suite"])] = r["disc_delta"]

    n_models = len(model_order)
    n_suites = len(suite_labels)
    data = np.full((n_models, n_suites), np.nan)
    for i, m in enumerate(model_order):
        for j, s in enumerate(suite_labels):
            val = lookup.get((m, s))
            if val is not None:
                data[i, j] = val

    fig, ax = plt.subplots(figsize=(5.5, 5.2))

    cmap = plt.cm.RdBu_r.copy()
    cmap.set_bad("#f0f0f0")
    vmax = 0.95
    im = ax.imshow(data, cmap=cmap, vmin=-vmax, vmax=vmax,
                   aspect="auto", interpolation="nearest")

    for i in range(n_models):
        for j in range(n_suites):
            val = data[i, j]
            if np.isnan(val):
                ax.text(j, i, "—", ha="center", va="center",
                        fontsize=8, color="#888888")
            else:
                color = "white" if abs(val) > 0.4 else "black"
                ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                        fontsize=7.5, color=color, fontweight="medium")

    ax.set_xticks(range(n_suites))
    ax.set_xticklabels(suite_labels, fontsize=10)
    ax.set_yticks(range(n_models))
    ax.set_yticklabels(model_order, fontsize=9)
    ax.tick_params(top=True, bottom=False, labeltop=True, labelbottom=False)

    divider_y = len(OW_MODEL_ORDER) - 0.5
    ax.axhline(y=divider_y, color="black", linewidth=1.5, linestyle="-")

    ax.annotate("Open-weight", xy=(-0.02, divider_y / 2),
                xycoords=("axes fraction", "data"), fontsize=7.5,
                fontstyle="italic", color="#444444", rotation=90,
                ha="right", va="center", annotation_clip=False)
    api_center = divider_y + (len(API_MODEL_ORDER)) / 2
    ax.annotate("API", xy=(-0.02, api_center),
                xycoords=("axes fraction", "data"), fontsize=7.5,
                fontstyle="italic", color="#444444", rotation=90,
                ha="right", va="center", annotation_clip=False)

    cbar = fig.colorbar(im, ax=ax, shrink=0.75, pad=0.04)
    cbar.set_label(r"Disc$_{\Delta}$ (UAI$_{\mathrm{pls}}$ $-$ UAI$_{\mathrm{irr}}$)",
                   fontsize=10)
    cbar.ax.tick_params(labelsize=9)

    ax.set_title(r"Discrimination gap across suites and models", fontsize=11,
                 pad=30)

    plt.tight_layout()
    out = FIG_DIR / "fig2_disc_heatmap.pdf"
    fig.savefig(out, bbox_inches="tight", dpi=300)
    fig.savefig(out.with_suffix(".png"), bbox_inches="tight", dpi=300)
    plt.close(fig)
    print(f"Saved: {out}")


def fig_acc_vs_disc(records):
    """Figure 3: Accuracy vs Disc_Δ scatter."""
    fig, ax = plt.subplots(figsize=(5.5, 4.0))

    for r in records:
        acc = r["acc10"]
        disc = r["disc_delta"]
        suite = r["suite"]
        is_api = r["is_api"]
        if acc is None or disc is None:
            continue

        color = SUITE_COLORS.get(suite, "#333333")
        marker = "D" if is_api else "o"
        size = 55 if is_api else 35
        edge = "black" if is_api else "none"
        ew = 0.8 if is_api else 0
        alpha = 0.85

        ax.scatter(acc * 100, disc, c=color, marker=marker, s=size,
                   edgecolors=edge, linewidths=ew, alpha=alpha, zorder=3)

    suite_handles = [
        mpatches.Patch(color=SUITE_COLORS[s], label=s)
        for s in ["External", "History", "ICL", "RAG", "Tool"]
    ]
    type_handles = [
        plt.Line2D([0], [0], marker="o", color="gray", markersize=6,
                   linestyle="None", label="Open-weight"),
        plt.Line2D([0], [0], marker="D", color="gray", markersize=6,
                   markeredgecolor="black", markeredgewidth=0.8,
                   linestyle="None", label="API"),
    ]

    leg1 = ax.legend(handles=suite_handles, loc="upper left",
                     fontsize=7.5, title="Suite", title_fontsize=8,
                     framealpha=0.9)
    ax.add_artist(leg1)
    ax.legend(handles=type_handles, loc="lower right",
              fontsize=7.5, title="Model type", title_fontsize=8,
              framealpha=0.9)

    ax.axhline(y=0, color="#cccccc", linewidth=0.8, linestyle="--", zorder=1)

    valid = [(r["acc10"] * 100, r["disc_delta"])
             for r in records
             if r["acc10"] is not None and r["disc_delta"] is not None]
    xs, ys = zip(*valid)
    r_val = np.corrcoef(xs, ys)[0, 1]
    ax.text(0.50, 0.98, f"Pearson $r$ = {r_val:.2f}",
            transform=ax.transAxes, ha="center", va="top",
            fontsize=8.5, fontstyle="italic",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white",
                      edgecolor="#cccccc", alpha=0.9))

    ax.set_xlabel(r"Task accuracy (Acc$_{10}$, %)", fontsize=10)
    ax.set_ylabel(r"Disc$_{\Delta}$", fontsize=10)
    ax.set_xlim(15, 105)
    ax.set_ylim(-0.15, 0.95)
    ax.tick_params(labelsize=9)
    ax.grid(True, alpha=0.2, linewidth=0.5)

    plt.tight_layout()
    out = FIG_DIR / "fig3_acc_vs_disc.pdf"
    fig.savefig(out, bbox_inches="tight", dpi=300)
    fig.savefig(out.with_suffix(".png"), bbox_inches="tight", dpi=300)
    plt.close(fig)
    print(f"Saved: {out}")


if __name__ == "__main__":
    records = load_data()
    print(f"Loaded {len(records)} records")
    fig_disc_heatmap(records)
    fig_acc_vs_disc(records)
    print("All figures generated.")
