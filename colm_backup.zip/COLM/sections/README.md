# Paper sections layout

| File | Role |
|------|------|
| `abstract.tex` | Abstract (included in `colm2026_conference.tex` before §1) |
| `introduction.tex` | § Introduction |
| `related_work.tex` | § Related work |
| `methodology.tex` | § Methodology — merged benchmark design + evaluation metrics |
| `experiments.tex` | § Experiments — setup, results, analysis |
| `conclusion.tex` | § Conclusion — limitations, future work, summary |
| `appendix/` | Appendix-only fragments (each `\input` from main tex after `\appendix`) |

### Appendix files (`appendix/`)

- `setup.tex` — models, hardware, parsing, reproducibility
- `per_suite.tex` — full per-suite metric tables
- `history_secondary.tex` — ACR / RR (History suite)
- `mitigations.tex` — mitigation strategy catalog
- `mechanistic.tex` — preliminary mechanistic notes
